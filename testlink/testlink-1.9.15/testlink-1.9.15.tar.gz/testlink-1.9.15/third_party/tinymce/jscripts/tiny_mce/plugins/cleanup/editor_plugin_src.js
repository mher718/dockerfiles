/**
 * $Id: editor_plugin_src.js,v 1.1 2007/12/03 08:52:35 franciscom Exp $
 *
 * Experimental plugin for new Cleanup routine, this logic will be moved into the core ones it's stable enougth.
 *
 * @author Moxiecode
 * @copyright Copyright � 2004-2007, Moxiecode Systems AB, All rights reserved.
 */

/* Dummy file since cleanup is now moved to core */
